# elgaara-onbook

Nama Kelompok
- I Dewa Agung Vigo Surya Rajasa (220030096)
- Made Wrahasta Dharma Pala (220030249)
- I Made Pande Krishna Bonaparta (220030480)
- Ni Kadek Ayu Puspayani (230030551)
- Ni Luh Putu Arinda Ardhiaswari (230030123)

wakakakakakaka